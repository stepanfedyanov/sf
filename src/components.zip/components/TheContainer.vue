<template>
  <div class="container">
    <slot />
  </div>
</template>

<style lang="scss">
.container {
  max-width: 1046px;
  margin: 0 auto;
}
</style>
